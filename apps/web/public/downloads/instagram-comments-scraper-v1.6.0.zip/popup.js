const scrapeBtn = document.getElementById('scrapeBtn');
const statusBox = document.getElementById('statusBox');
const statusLine = document.getElementById('statusLine');
const progressFill = document.getElementById('progressFill');
const percentLabel = document.getElementById('percent');
const etaLabel = document.getElementById('eta');
const phaseLabel = document.getElementById('phase');
const detailLabel = document.getElementById('detail');
const apiUrlInput = document.getElementById('apiUrl');
const apiKeyInput = document.getElementById('apiKey');

function showStatusBox() {
  statusBox.style.display = 'block';
}

function formatSeconds(secs) {
  if (!isFinite(secs) || secs <= 0) return '--:--';
  const m = Math.floor(secs / 60);
  const s = Math.round(secs % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

function setPopupProgress({ phaseText = null, percent = null, eta = null, detail = null }) {
  showStatusBox();
  if (phaseText !== null) phaseLabel.textContent = `phase: ${phaseText}`;
  if (percent !== null) {
    const pct = Math.max(0, Math.min(100, Math.round(percent)));
    progressFill.style.width = `${pct}%`;
    percentLabel.textContent = `${pct}%`;
  }
  if (eta !== null) etaLabel.textContent = `ETA: ${eta}`;
  if (detail !== null) detailLabel.textContent = detail;
}

function resetPopupState() {
  progressFill.style.width = '0%';
  percentLabel.textContent = '0%';
  etaLabel.textContent = 'ETA: --:--';
  phaseLabel.textContent = 'phase: idle';
  detailLabel.textContent = '';
}

function loadSaasConfig() {
  try {
    apiUrlInput.value = localStorage.getItem('igSaasApiUrl') || 'http://localhost:8080';
    apiKeyInput.value = localStorage.getItem('igSaasApiKey') || '';
  } catch {}
}

function saveSaasConfig() {
  try {
    localStorage.setItem('igSaasApiUrl', (apiUrlInput.value || '').trim());
    localStorage.setItem('igSaasApiKey', (apiKeyInput.value || '').trim());
  } catch {}
}

loadSaasConfig();
apiUrlInput.addEventListener('change', saveSaasConfig);
apiKeyInput.addEventListener('change', saveSaasConfig);

let scrapeStart = 0;
let estimatedTotal = null;
let processed = 0;

chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.type !== 'ig-progress') return;

  const now = Date.now();
  if (msg.phase === 'start') {
    scrapeStart = now;
    estimatedTotal = msg.total_estimate || null;
    processed = 0;
    statusLine.textContent = 'Status: started';
    setPopupProgress({ phaseText: 'starting', percent: 0, detail: 'Initializing scraper...' });
    return;
  }

  if (msg.phase === 'progress') {
    processed = msg.itemsFetchedSoFar || processed;
    const pct = msg.percent ?? (estimatedTotal ? (processed / estimatedTotal) * 100 : null);
    let eta = '--:--';
    if (estimatedTotal && processed > 0) {
      const elapsed = (now - scrapeStart) / 1000;
      const etaSecs = (elapsed / processed) * (estimatedTotal - processed);
      eta = formatSeconds(etaSecs);
    }
    statusLine.textContent = `Status: ${msg.status || 'running'}`;
    setPopupProgress({ phaseText: msg.phaseText || 'running', percent: pct, eta, detail: msg.detail || '' });
    return;
  }

  if (msg.phase === 'done') {
    statusLine.textContent = 'Status: done - CSV downloaded';
    setPopupProgress({ phaseText: 'done', percent: 100, eta: '00:00', detail: `Rows: ${msg.totalRows || 0}${msg.uploadResult ? ' | ' + msg.uploadResult : ''}` });
    setTimeout(() => {
      scrapeBtn.disabled = false;
      scrapeBtn.textContent = 'Scrape Comments';
    }, 700);
    return;
  }

  if (msg.phase === 'error') {
    statusLine.textContent = `Status: error - ${msg.message || 'unknown'}`;
    setPopupProgress({ phaseText: 'error', detail: msg.message || 'Unknown error' });
    scrapeBtn.disabled = false;
    scrapeBtn.textContent = 'Scrape Comments';
  }
});

scrapeBtn.addEventListener('click', async () => {
  const threadedReplies = document.getElementById('threadedToggle').checked;
  const fetchProfiles = document.getElementById('profilesToggle').checked;
  const saasApiUrl = (apiUrlInput.value || '').trim();
  const saasApiKey = (apiKeyInput.value || '').trim();

  saveSaasConfig();
  resetPopupState();
  scrapeBtn.disabled = true;
  scrapeBtn.textContent = 'Launching...';
  statusLine.textContent = 'Status: initializing...';
  showStatusBox();

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !tab.url || !/instagram\.com/.test(tab.url)) {
      throw new Error('Open an Instagram post/reel/tv in the active tab first.');
    }

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: injectedScraper,
      args: [{ threadedReplies, fetchProfiles, saasApiUrl, saasApiKey }]
    });

    scrapeBtn.textContent = 'Running...';
    statusLine.textContent = 'Status: scraper running on page';
  } catch (err) {
    statusLine.textContent = `Error: ${err.message || String(err)}`;
    scrapeBtn.disabled = false;
    scrapeBtn.textContent = 'Scrape Comments';
  }
});

function injectedScraper(options = { threadedReplies: true, fetchProfiles: true, saasApiUrl: '', saasApiKey: '' }) {
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const MAX_ROWS = 100000;
  const GRAPHQL_HASHES = ['97b41c52301f77ce508f55e66d17620e', 'f0986789a5c5d17c2400faebf16efd0d', 'd5d763b1e2acf209d62d22d184488e57'];

  function notify(payload) {
    try {
      chrome.runtime.sendMessage({ type: 'ig-progress', ...payload });
    } catch {}
  }

  function overlay(text, sub) {
    let root = document.getElementById('__ig_scraper_overlay');
    if (!root) {
      root = document.createElement('div');
      root.id = '__ig_scraper_overlay';
      root.style = 'position:fixed;top:16px;right:16px;z-index:2147483647;background:#111827;color:#fff;padding:10px 12px;border-radius:10px;font:13px Segoe UI,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.28);max-width:320px;';
      document.documentElement.appendChild(root);
    }
    root.textContent = `${text}${sub ? ' - ' + sub : ''}`;
  }

  function finishOverlay() {
    const root = document.getElementById('__ig_scraper_overlay');
    if (root) setTimeout(() => root.remove(), 1200);
  }

  function getShortcode() {
    const parts = location.pathname.split('/').filter(Boolean);
    for (let i = 0; i < parts.length; i += 1) {
      const s = parts[i].toLowerCase();
      if (s === 'p' || s === 'reel' || s === 'tv') return parts[i + 1] || null;
    }
    const og = document.querySelector('meta[property="og:url"]')?.content || '';
    const m = og.match(/\/(p|reel|tv)\/([^\ /?#]+)/);
    return m?.[2] || null;
  }

  function normalizeNode(node) {
    const id = node?.id || node?.pk || '';
    const username = node?.owner?.username || node?.user?.username || 'unknown';
    const text = String(node?.text || node?.comment_text || '').replace(/\s+/g, ' ').trim();
    const created = Number(node?.created_at || node?.created_time || node?.taken_at_timestamp || 0);
    const timestampIso = created ? new Date(created * 1000).toISOString() : '';
    const likeCount = Number(node?.edge_liked_by?.count || node?.like_count || 0);
    const replies = node?.edge_threaded_comments?.edges || [];
    return { id, username, text, timestampIso, likeCount, replies };
  }

  async function fetchJson(url) {
    for (let i = 0; i < 3; i += 1) {
      try {
        const res = await fetch(url, { credentials: 'same-origin' });
        if (res.ok) return await res.json();
        if (res.status === 429) await sleep(600 * (i + 1));
      } catch {
        await sleep(400 * (i + 1));
      }
    }
    return null;
  }

  async function scrapeViaA1(shortcode) {
    const paths = [`/p/${shortcode}/`, `/reel/${shortcode}/`, `/tv/${shortcode}/`];
    for (const path of paths) {
      const data = await fetchJson(`https://www.instagram.com${path}?__a=1&__d=dis`);
      const conn = data?.graphql?.shortcode_media?.edge_media_to_parent_comment;
      if (conn?.edges?.length) {
        return {
          edges: conn.edges,
          pageInfo: conn.page_info || null,
          source: 'a1',
          totalCount: conn.count || null
        };
      }
    }
    return null;
  }

  async function fetchGraphqlPage(shortcode, after = null) {
    for (const hash of GRAPHQL_HASHES) {
      const vars = encodeURIComponent(JSON.stringify({ shortcode, first: 50, after }));
      const data = await fetchJson(`https://www.instagram.com/graphql/query/?query_hash=${hash}&variables=${vars}`);
      const conn = data?.data?.shortcode_media?.edge_media_to_parent_comment;
      if (conn) return { edges: conn.edges || [], pageInfo: conn.page_info || null };
    }
    return null;
  }

  async function scrapeViaGraphql(shortcode, initialEdges = [], initialPageInfo = null) {
    const out = [...initialEdges];
    let pageInfo = initialPageInfo;
    let rounds = 0;

    while (pageInfo?.has_next_page && pageInfo?.end_cursor && rounds < 400) {
      const page = await fetchGraphqlPage(shortcode, pageInfo.end_cursor);
      if (!page?.edges?.length) break;
      out.push(...page.edges);
      pageInfo = page.pageInfo;
      rounds += 1;

      notify({
        phase: 'progress',
        phaseText: 'graphql',
        status: `fetched page ${rounds}`,
        itemsFetchedSoFar: out.length,
        detail: `${out.length} comments`
      });
      overlay('Fetching comments', `${out.length} comments`);
      await sleep(180);
    }

    return out;
  }

  async function expandDomComments(maxRounds = 30) {
    const clickTexts = ['load more comments', 'view all', 'more comments', 'view replies', 'more replies'];

    for (let r = 0; r < maxRounds; r += 1) {
      let clicked = 0;
      const buttons = Array.from(document.querySelectorAll('button, div[role="button"]'));

      for (const el of buttons) {
        const text = (el.textContent || '').toLowerCase();
        if (clickTexts.some((t) => text.includes(t))) {
          try {
            el.click();
            clicked += 1;
            await sleep(120);
          } catch {}
        }
      }

      window.scrollBy({ top: 1200, behavior: 'smooth' });
      await sleep(400);

      if (clicked === 0 && r > 4) break;
      notify({ phase: 'progress', phaseText: 'dom-expand', status: `expanding ${r + 1}`, detail: `clicked ${clicked}` });
      overlay('Expanding comments', `round ${r + 1}`);
    }
  }

  function scrapeViaDom() {
    const rows = [];
    const seen = new Set();

    const commentItems = Array.from(document.querySelectorAll('ul ul li, article ul li'));
    for (const li of commentItems) {
      const usernameEl = li.querySelector('a[href^="/"]');
      const textEl = li.querySelector('span');
      if (!usernameEl || !textEl) continue;

      const username = (usernameEl.textContent || '').trim();
      const text = (textEl.textContent || '').trim();
      if (!username || !text) continue;

      const key = `${username}|${text}`;
      if (seen.has(key)) continue;
      seen.add(key);

      rows.push({
        CommentID: `dom_${seen.size}`,
        ParentID: '',
        IsReply: 'false',
        Username: username,
        Text: text,
        Timestamp_ISO: '',
        Timestamp_IST: '',
        LikeCount: 0,
        ReplyCount: 0,
        Source: 'dom'
      });

      if (rows.length >= MAX_ROWS) break;
    }

    return rows;
  }

  async function fetchProfile(username) {
    try {
      const data = await fetchJson(`https://www.instagram.com/${username}/?__a=1&__d=dis`);
      const user = data?.graphql?.user || data?.user || null;
      if (!user) return null;
      return {
        fullName: user.full_name || '',
        profilePicUrl: user.profile_pic_url_hd || user.profile_pic_url || '',
        isVerified: Boolean(user.is_verified),
        followersCount: Number(user.edge_followed_by?.count || user.followers_count || 0),
        profileUrl: `https://www.instagram.com/${username}/`
      };
    } catch {
      return null;
    }
  }

  function csvEscape(value) {
    return `"${String(value ?? '').replace(/"/g, '""')}"`;
  }

  function buildCsv(rows) {
    const headers = ['CommentID', 'ParentID', 'IsReply', 'Username', 'Text', 'Timestamp_ISO', 'Timestamp_IST', 'LikeCount', 'ReplyCount', 'Source', 'ProfileFullName', 'ProfilePicURL', 'IsVerifiedProfile', 'FollowersCount', 'ProfileURL'];
    const lines = rows.map((r) => [
      csvEscape(r.CommentID),
      csvEscape(r.ParentID),
      r.IsReply,
      csvEscape(r.Username),
      csvEscape(r.Text),
      csvEscape(r.Timestamp_ISO),
      csvEscape(r.Timestamp_IST),
      Number(r.LikeCount || 0),
      Number(r.ReplyCount || 0),
      csvEscape(r.Source),
      csvEscape(r.ProfileFullName || ''),
      csvEscape(r.ProfilePicURL || ''),
      csvEscape(r.IsVerifiedProfile || 'false'),
      Number(r.FollowersCount || 0),
      csvEscape(r.ProfileURL || '')
    ].join(','));

    return [headers.join(','), ...lines].join('\n');
  }

  async function uploadRows(rows, shortcode) {
    if (!options.saasApiUrl || !options.saasApiKey) return null;

    try {
      const url = `${options.saasApiUrl.replace(/\/$/, '')}/scrape-jobs`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': options.saasApiKey },
        body: JSON.stringify({
          metadata: { shortcode, exportedAt: new Date().toISOString(), sourceType: 'extension' },
          rows
        })
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return `upload_failed:${data.error || res.status}`;
      return `uploaded_job:${data.jobId || 'ok'}`;
    } catch (err) {
      return `upload_error:${err.message || String(err)}`;
    }
  }

  (async () => {
    notify({ phase: 'start', total_estimate: null });
    overlay('Starting scraper', 'validating page');

    try {
      const shortcode = getShortcode();
      if (!shortcode) throw new Error('shortcode_not_found');

      const a1 = await scrapeViaA1(shortcode);
      const topEdges = a1?.edges || [];
      const pageInfo = a1?.pageInfo || null;
      const totalEstimate = a1?.totalCount || null;

      notify({ phase: 'progress', phaseText: 'collect', status: 'collecting comments', total_estimate: totalEstimate, itemsFetchedSoFar: topEdges.length, detail: `${topEdges.length} initial` });
      overlay('Collecting comments', `${topEdges.length} initial`);

      let edges = topEdges;
      if (!edges.length || pageInfo?.has_next_page) {
        const gqlEdges = await scrapeViaGraphql(shortcode, edges, pageInfo);
        if (gqlEdges.length) edges = gqlEdges;
      }

      const rows = [];
      const seen = new Set();

      for (const edge of edges) {
        const node = edge?.node || edge;
        const top = normalizeNode(node);
        if (!top.id || !top.text) continue;
        if (seen.has(top.id)) continue;
        seen.add(top.id);

        rows.push({
          CommentID: top.id,
          ParentID: '',
          IsReply: 'false',
          Username: top.username,
          Text: top.text,
          Timestamp_ISO: top.timestampIso,
          Timestamp_IST: top.timestampIso,
          LikeCount: top.likeCount,
          ReplyCount: Array.isArray(top.replies) ? top.replies.length : 0,
          Source: a1?.source || 'graphql'
        });

        if (options.threadedReplies && Array.isArray(top.replies)) {
          for (const repEdge of top.replies) {
            const rep = normalizeNode(repEdge?.node || repEdge);
            if (!rep.id || !rep.text) continue;
            if (seen.has(rep.id)) continue;
            seen.add(rep.id);

            rows.push({
              CommentID: rep.id,
              ParentID: top.id,
              IsReply: 'true',
              Username: rep.username,
              Text: rep.text,
              Timestamp_ISO: rep.timestampIso,
              Timestamp_IST: rep.timestampIso,
              LikeCount: rep.likeCount,
              ReplyCount: 0,
              Source: 'inline_reply'
            });
          }
        }

        if (rows.length >= MAX_ROWS) break;
      }

      if (!rows.length) {
        notify({ phase: 'progress', phaseText: 'dom-fallback', status: 'expanding comments in DOM', detail: 'API paths gave no rows' });
        overlay('Fallback mode', 'expanding DOM comments');
        await expandDomComments();
        const domRows = scrapeViaDom();
        rows.push(...domRows);
      }

      if (!rows.length) throw new Error('no_comments_found');

      notify({ phase: 'progress', phaseText: 'finalize', status: 'finalizing rows', itemsFetchedSoFar: rows.length, detail: `${rows.length} rows` });
      overlay('Finalizing', `${rows.length} rows`);

      if (options.fetchProfiles) {
        const uniqueUsers = Array.from(new Set(rows.map((r) => r.Username).filter(Boolean))).slice(0, 4000);
        let done = 0;

        for (const username of uniqueUsers) {
          const profile = await fetchProfile(username);
          rows.forEach((r) => {
            if (r.Username !== username) return;
            r.ProfileFullName = profile?.fullName || '';
            r.ProfilePicURL = profile?.profilePicUrl || '';
            r.IsVerifiedProfile = profile?.isVerified ? 'true' : 'false';
            r.FollowersCount = profile?.followersCount || 0;
            r.ProfileURL = profile?.profileUrl || `https://www.instagram.com/${username}/`;
          });
          done += 1;

          if (done % 10 === 0) {
            notify({ phase: 'progress', phaseText: 'profiles', status: `profiles ${done}/${uniqueUsers.length}`, detail: `${done}/${uniqueUsers.length}` });
          }
          await sleep(80);
        }
      }

      rows.forEach((r) => {
        if (!r.ProfileURL) r.ProfileURL = `https://www.instagram.com/${r.Username}/`;
        if (!r.IsVerifiedProfile) r.IsVerifiedProfile = 'false';
      });

      const csv = buildCsv(rows);
      const filename = `instagram_comments_${shortcode}_${Date.now()}.csv`;
      const blob = new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8;' });
      const blobUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(blobUrl), 2500);

      const uploadResult = await uploadRows(rows, shortcode);

      notify({ phase: 'done', totalRows: rows.length, uploadResult });
      overlay('Done', `${rows.length} rows`);
      finishOverlay();
    } catch (err) {
      notify({ phase: 'error', message: err.message || String(err) });
      overlay('Error', err.message || 'unknown');
      finishOverlay();
    }
  })();
}
